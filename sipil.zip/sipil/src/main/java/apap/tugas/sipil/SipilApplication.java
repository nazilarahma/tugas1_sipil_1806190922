package apap.tugas.sipil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SipilApplication {

	public static void main(String[] args) {
		SpringApplication.run(SipilApplication.class, args);
	}

}
